# Sign Language > 2024-11-20 1:29am
https://universe.roboflow.com/isl-6akhx/sign-language-sbyob

Provided by a Roboflow user
License: CC BY 4.0

